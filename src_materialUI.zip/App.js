import React from "react";
import ColorThemeTutorial from "./components/ColorThemeTutorial";
// import StepperTutorial2 from "./components/StepperTutorial2";
// import StepperHooks from "./components/StepperTutorial1";
// import IconTutorial from "./components/IconTutorial";
// import TabTutorial from "./components/TabTutorial";
// import GridTutorial1 from "./components/GridTutorial1";
// import GridTutorial2 from "./components/GridTutorial2";

function App() {
  

  return (
    <div className="App">
      {/* <GridTutorial1 /> */}
      {/* <GridTutorial2 /> */}
      {/* <TabTutorial /> */}
      {/* <IconTutorial /> */}
      {/* <StepperHooks /> */}
      {/* <StepperTutorial2 /> */}
      <ColorThemeTutorial />
    </div>
  );
}

export default App;
